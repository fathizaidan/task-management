@extends('layouts.app')
@section('title', $board->title)

@section('content')
{{-- Board Header --}}
<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
    <div class="flex items-center gap-3">
        <div class="w-4 h-4 rounded-full" style="background-color: {{ $board->color }}"></div>
        <h1 class="text-2xl font-bold text-gray-900">{{ $board->title }}</h1>
        @if($board->description)
            <span class="text-gray-400 text-sm hidden md:inline">— {{ $board->description }}</span>
        @endif
    </div>
    <div class="flex gap-2">
        <a href="{{ route('boards.edit', $board) }}"
           class="text-sm bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
            </svg>
            Edit Board
        </a>
        <a href="{{ route('dashboard') }}"
           class="text-sm bg-white hover:bg-gray-50 border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg transition">
            ← Back
        </a>
    </div>
</div>

{{-- Kanban Board --}}
<div id="board-container" class="flex gap-4 overflow-x-auto pb-6 items-start"
     data-board-id="{{ $board->id }}"
     data-reorder-url="{{ route('task-lists.reorder', $board) }}"
     data-move-url="{{ route('tasks.move') }}">

    @foreach($board->taskLists as $list)
    <div class="task-list-column bg-gray-200 rounded-xl w-72 shrink-0 flex flex-col"
         data-list-id="{{ $list->id }}">

        {{-- List Header --}}
        <div class="flex items-center justify-between px-3 pt-3 pb-2">
            <span class="font-semibold text-gray-800 text-sm">{{ $list->title }}</span>
            <div class="flex items-center gap-1">
                <span class="text-xs text-gray-500 bg-gray-300 rounded-full px-2 py-0.5">
                    {{ $list->tasks->count() }}
                </span>
                <div class="relative group">
                    <button class="p-1 rounded hover:bg-gray-300 transition text-gray-500">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 6a2 2 0 110-4 2 2 0 010 4zm0 6a2 2 0 110-4 2 2 0 010 4zm0 6a2 2 0 110-4 2 2 0 010 4z"/>
                        </svg>
                    </button>
                    <div class="absolute right-0 top-7 bg-white shadow-lg rounded-lg py-1 z-20 w-36 hidden group-hover:block">
                        <form method="POST" action="{{ route('task-lists.destroy', $list) }}"
                              onsubmit="return confirm('Delete this list and all its tasks?')">
                            @csrf @method('DELETE')
                            <button class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                Delete List
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        {{-- Task Cards --}}
        <div class="task-cards px-2 pb-2 flex flex-col gap-2 min-h-[4rem]"
             data-list-id="{{ $list->id }}">
            @foreach($list->tasks as $task)
            <div class="task-card bg-white rounded-lg shadow-sm p-3 cursor-pointer hover:shadow-md transition group"
                 data-task-id="{{ $task->id }}">

                {{-- Priority badge --}}
                <div class="flex items-start justify-between gap-2">
                    <a href="{{ route('tasks.edit', $task) }}" class="font-medium text-gray-800 text-sm leading-snug hover:text-indigo-600 flex-1">
                        {{ $task->title }}
                    </a>
                    <span class="shrink-0 text-xs px-1.5 py-0.5 rounded-full font-medium
                        {{ $task->priority === 'high' ? 'bg-red-100 text-red-700' : ($task->priority === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700') }}">
                        {{ ucfirst($task->priority) }}
                    </span>
                </div>

                @if($task->description)
                    <p class="text-xs text-gray-400 mt-1 line-clamp-2">{{ $task->description }}</p>
                @endif

                <div class="flex items-center justify-between mt-2">
                    {{-- Status badge --}}
                    <span class="text-xs rounded-full px-2 py-0.5
                        {{ $task->status === 'done' ? 'bg-green-100 text-green-700' : ($task->status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600') }}">
                        {{ $task->statusLabel() }}
                    </span>

                    {{-- Due date --}}
                    @if($task->due_date)
                    <span class="text-xs {{ $task->isOverdue() ? 'text-red-500 font-semibold' : 'text-gray-400' }}">
                        📅 {{ $task->due_date->format('M j') }}
                    </span>
                    @endif
                </div>

                {{-- Edit / Delete actions (visible on hover) --}}
                <div class="flex gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <a href="{{ route('tasks.edit', $task) }}"
                       class="text-xs text-indigo-500 hover:underline">Edit</a>
                    <span class="text-gray-300">|</span>
                    <form method="POST" action="{{ route('tasks.destroy', $task) }}" class="inline"
                          onsubmit="return confirm('Delete this task?')">
                        @csrf @method('DELETE')
                        <button class="text-xs text-red-400 hover:underline">Delete</button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>

        {{-- Add Task --}}
        <div class="px-2 pb-3">
            <a href="{{ route('tasks.create', $list) }}"
               class="flex items-center gap-1 w-full text-left text-sm text-gray-500 hover:text-gray-700 hover:bg-gray-300 rounded-lg px-2 py-1.5 transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Add a card
            </a>
        </div>
    </div>
    @endforeach

    {{-- Add List Form --}}
    <div class="w-72 shrink-0">
        <div id="add-list-toggle" class="bg-white/70 hover:bg-white rounded-xl p-3 cursor-pointer transition"
             onclick="document.getElementById('add-list-form').classList.remove('hidden'); this.classList.add('hidden')">
            <span class="flex items-center gap-1 text-sm font-medium text-gray-600">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Add another list
            </span>
        </div>

        <div id="add-list-form" class="bg-gray-200 rounded-xl p-3 hidden">
            <form method="POST" action="{{ route('task-lists.store', $board) }}">
                @csrf
                <input type="text" name="title" placeholder="List name" required
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none mb-2"
                       autofocus>
                <div class="flex gap-2">
                    <button type="submit"
                            class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-1.5 rounded-lg transition">
                        Add List
                    </button>
                    <button type="button"
                            class="text-gray-500 hover:text-gray-700 text-sm px-2 py-1.5 transition"
                            onclick="document.getElementById('add-list-form').classList.add('hidden'); document.getElementById('add-list-toggle').classList.remove('hidden')">
                        ✕
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="{{ asset('js/dragdrop.js') }}"></script>
@endpush
