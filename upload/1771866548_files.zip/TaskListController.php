<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTaskListRequest;
use App\Models\Board;
use App\Models\TaskList;
use Illuminate\Http\Request;

class TaskListController extends Controller
{
    /**
     * Store a new list inside a board.
     */
    public function store(StoreTaskListRequest $request, Board $board)
    {
        $this->authorize('update', $board);

        $position = $board->taskLists()->max('position') + 1;

        $board->taskLists()->create([
            'title'    => $request->validated('title'),
            'position' => $position,
        ]);

        return redirect()
            ->route('boards.show', $board)
            ->with('success', 'List added!');
    }

    /**
     * Update list title.
     */
    public function update(StoreTaskListRequest $request, TaskList $taskList)
    {
        $this->authorize('update', $taskList->board);
        $taskList->update($request->validated());

        return back()->with('success', 'List updated!');
    }

    /**
     * Delete a list (cascades to tasks).
     */
    public function destroy(TaskList $taskList)
    {
        $board = $taskList->board;
        $this->authorize('update', $board);
        $taskList->delete();

        return redirect()
            ->route('boards.show', $board)
            ->with('success', 'List deleted.');
    }

    /**
     * AJAX: reorder lists within a board.
     * Body: { "order": [3, 1, 4, 2] }   — array of list IDs in new order
     */
    public function reorder(Request $request, Board $board)
    {
        $this->authorize('update', $board);

        $request->validate([
            'order'   => 'required|array',
            'order.*' => 'integer',
        ]);

        foreach ($request->order as $position => $id) {
            $board->taskLists()->where('id', $id)->update(['position' => $position]);
        }

        return response()->json(['status' => 'ok']);
    }
}
