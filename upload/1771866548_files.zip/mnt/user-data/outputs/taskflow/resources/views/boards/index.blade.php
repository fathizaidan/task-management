@extends('layouts.app')
@section('title', 'All Boards')

@section('content')
<div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold text-gray-800">All Boards</h1>
    <a href="{{ route('boards.create') }}"
       class="inline-flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
        + New Board
    </a>
</div>

@if($boards->isEmpty())
    <p class="text-gray-500">No boards yet. <a href="{{ route('boards.create') }}" class="text-indigo-600 hover:underline">Create one</a>.</p>
@else
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        @foreach($boards as $board)
        <div class="bg-white rounded-2xl shadow overflow-hidden flex flex-col">
            <div class="h-2 w-full" style="background-color: {{ $board->color }}"></div>
            <div class="p-5 flex flex-col flex-1">
                <h2 class="font-bold text-gray-900 text-lg">{{ $board->title }}</h2>
                @if($board->description)
                    <p class="text-sm text-gray-500 mt-1 line-clamp-2">{{ $board->description }}</p>
                @endif
                <div class="mt-auto pt-4 flex gap-2">
                    <a href="{{ route('boards.show', $board) }}"
                       class="flex-1 text-center text-sm bg-indigo-600 hover:bg-indigo-700 text-white py-1.5 rounded-lg transition">
                        Open
                    </a>
                    <a href="{{ route('boards.edit', $board) }}"
                       class="px-3 text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 py-1.5 rounded-lg transition">
                        Edit
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
@endif
@endsection
