# TaskFlow — Trello-like Task Manager (Laravel)

## Tech Stack
- Laravel 11 (latest stable)
- Blade + Tailwind CSS
- MySQL + Eloquent ORM
- Laravel Breeze (auth)
- Vanilla JS drag & drop via SortableJS (CDN)

---

## Setup

```bash
# 1. Create Laravel project
composer create-project laravel/laravel taskflow
cd taskflow

# 2. Install Breeze
composer require laravel/breeze --dev
php artisan breeze:install blade

# 3. Install frontend deps
npm install && npm run build

# 4. Copy all files from this repo over the project structure

# 5. Configure .env
DB_DATABASE=taskflow
DB_USERNAME=root
DB_PASSWORD=your_password

# 6. Run migrations
php artisan migrate

# 7. Start server
php artisan serve
```

---

## Project Structure

```
app/
├── Http/
│   ├── Controllers/
│   │   ├── BoardController.php
│   │   ├── TaskListController.php
│   │   ├── TaskController.php
│   │   └── DashboardController.php
│   └── Requests/
│       ├── StoreBoardRequest.php
│       ├── StoreTaskListRequest.php
│       └── StoreTaskRequest.php
├── Models/
│   ├── Board.php
│   ├── TaskList.php
│   └── Task.php
├── Policies/
│   ├── BoardPolicy.php
│   └── TaskPolicy.php
database/
├── migrations/
│   ├── create_boards_table.php
│   ├── create_task_lists_table.php
│   └── create_tasks_table.php
resources/
└── views/
    ├── layouts/
    │   └── app.blade.php
    ├── dashboard/
    │   └── index.blade.php
    ├── boards/
    │   ├── index.blade.php
    │   ├── create.blade.php
    │   ├── show.blade.php
    │   └── edit.blade.php
    └── tasks/
        ├── create.blade.php
        └── edit.blade.php
routes/
└── web.php
public/
└── js/
    └── dragdrop.js
```
