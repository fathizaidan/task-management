@extends('layouts.app')
@section('title', 'Edit Board')

@section('content')
<div class="max-w-xl mx-auto">
    <div class="mb-4">
        <a href="{{ route('boards.show', $board) }}" class="text-indigo-600 hover:underline text-sm">← Back to Board</a>
    </div>

    <div class="bg-white rounded-2xl shadow p-8">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Edit Board</h1>

        <form method="POST" action="{{ route('boards.update', $board) }}" class="space-y-5">
            @csrf
            @method('PUT')

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Title <span class="text-red-500">*</span></label>
                <input type="text" name="title" value="{{ old('title', $board->title) }}" required
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none @error('title') border-red-400 @enderror">
                @error('title')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea name="description" rows="3"
                          class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none">{{ old('description', $board->description) }}</textarea>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Board Color</label>
                <div class="flex flex-wrap gap-2">
                    @foreach(['#4F46E5','#0EA5E9','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#64748B'] as $color)
                    <label class="cursor-pointer">
                        <input type="radio" name="color" value="{{ $color }}"
                               class="sr-only"
                               {{ old('color', $board->color) === $color ? 'checked' : '' }}>
                        <span class="block w-8 h-8 rounded-full border-4 transition"
                              style="background-color: {{ $color }}; border-color: {{ old('color', $board->color) === $color ? '#1f2937' : 'transparent' }}">
                        </span>
                    </label>
                    @endforeach
                </div>
            </div>

            <div class="flex gap-3 pt-2">
                <button type="submit"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg transition">
                    Save Changes
                </button>
                <a href="{{ route('boards.show', $board) }}"
                   class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-2 rounded-lg transition">
                    Cancel
                </a>
            </div>
        </form>

        {{-- Danger zone --}}
        <div class="mt-8 pt-6 border-t border-red-100">
            <h3 class="text-sm font-semibold text-red-600 mb-3">Danger Zone</h3>
            <form method="POST" action="{{ route('boards.destroy', $board) }}"
                  onsubmit="return confirm('Delete this board and ALL its lists and tasks? This cannot be undone.')">
                @csrf
                @method('DELETE')
                <button type="submit"
                        class="bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 px-4 py-2 rounded-lg text-sm transition">
                    Delete Board
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
