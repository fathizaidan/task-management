<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBoardRequest;
use App\Models\Board;
use Illuminate\Http\Request;

class BoardController extends Controller
{
    public function index(Request $request)
    {
        $boards = $request->user()->boards()->latest()->get();
        return view('boards.index', compact('boards'));
    }

    public function create()
    {
        return view('boards.create');
    }

    public function store(StoreBoardRequest $request)
    {
        $board = $request->user()->boards()->create($request->validated());

        return redirect()
            ->route('boards.show', $board)
            ->with('success', 'Board created successfully!');
    }

    public function show(Board $board)
    {
        $this->authorize('view', $board);

        $board->load(['taskLists.tasks' => fn ($q) => $q->orderBy('position')]);

        return view('boards.show', compact('board'));
    }

    public function edit(Board $board)
    {
        $this->authorize('update', $board);
        return view('boards.edit', compact('board'));
    }

    public function update(StoreBoardRequest $request, Board $board)
    {
        $this->authorize('update', $board);
        $board->update($request->validated());

        return redirect()
            ->route('boards.show', $board)
            ->with('success', 'Board updated successfully!');
    }

    public function destroy(Board $board)
    {
        $this->authorize('delete', $board);
        $board->delete();

        return redirect()
            ->route('dashboard')
            ->with('success', 'Board deleted.');
    }
}
