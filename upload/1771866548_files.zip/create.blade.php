@extends('layouts.app')
@section('title', 'Create Board')

@section('content')
<div class="max-w-xl mx-auto">
    <div class="mb-4">
        <a href="{{ route('dashboard') }}" class="text-indigo-600 hover:underline text-sm">← Back to Dashboard</a>
    </div>

    <div class="bg-white rounded-2xl shadow p-8">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Create New Board</h1>

        <form method="POST" action="{{ route('boards.store') }}" class="space-y-5">
            @csrf

            {{-- Title --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Title <span class="text-red-500">*</span></label>
                <input type="text" name="title" value="{{ old('title') }}" required
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none @error('title') border-red-400 @enderror"
                       placeholder="My awesome project">
                @error('title')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            {{-- Description --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea name="description" rows="3"
                          class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="What is this board about?">{{ old('description') }}</textarea>
            </div>

            {{-- Color --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Board Color</label>
                <div class="flex flex-wrap gap-2">
                    @foreach(['#4F46E5','#0EA5E9','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#64748B'] as $color)
                    <label class="cursor-pointer">
                        <input type="radio" name="color" value="{{ $color }}"
                               class="sr-only"
                               {{ old('color', '#4F46E5') === $color ? 'checked' : '' }}>
                        <span class="block w-8 h-8 rounded-full ring-2 ring-offset-2 ring-transparent peer-checked:ring-gray-800 hover:ring-gray-400 transition"
                              style="background-color: {{ $color }}"
                              onclick="this.previousElementSibling.checked=true; document.querySelectorAll('[name=color]').forEach(r=>r!==this.previousElementSibling&&(r.nextElementSibling.style.ringColor='transparent')); this.style.outline='3px solid #1f2937'">
                        </span>
                    </label>
                    @endforeach
                </div>
            </div>

            <div class="flex gap-3 pt-2">
                <button type="submit"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg transition">
                    Create Board
                </button>
                <a href="{{ route('dashboard') }}"
                   class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-2 rounded-lg transition">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>
@endsection
