<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'TaskFlow') }} — @yield('title', 'Home')</title>

    {{-- Tailwind via CDN (replace with vite + npm build in production) --}}
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { DEFAULT: '#4F46E5', dark: '#3730A3' }
                    }
                }
            }
        }
    </script>

    {{-- SortableJS for drag & drop --}}
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>

    <style>
        [x-cloak] { display: none !important; }
        .sortable-ghost { opacity: 0.4; }
        .sortable-chosen { box-shadow: 0 10px 25px rgba(0,0,0,0.15); transform: rotate(1deg); }
    </style>
</head>
<body class="bg-gray-100 min-h-screen font-sans antialiased">

{{-- ── Navbar ── --}}
<nav class="bg-indigo-700 text-white shadow-lg">
    <div class="max-w-screen-xl mx-auto px-4 flex items-center justify-between h-14">
        {{-- Logo --}}
        <a href="{{ route('dashboard') }}" class="flex items-center gap-2 font-bold text-xl tracking-tight">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
            </svg>
            TaskFlow
        </a>

        {{-- Right side --}}
        @auth
        <div class="flex items-center gap-4 text-sm">
            <a href="{{ route('dashboard') }}" class="hover:text-indigo-200 transition">Dashboard</a>
            <a href="{{ route('boards.index') }}" class="hover:text-indigo-200 transition">Boards</a>
            <a href="{{ route('boards.create') }}"
               class="bg-white text-indigo-700 font-semibold px-3 py-1 rounded-lg hover:bg-indigo-50 transition">
               + New Board
            </a>
            <span class="text-indigo-300">|</span>
            <span class="text-indigo-200">{{ auth()->user()->name }}</span>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="hover:text-indigo-200 transition">Logout</button>
            </form>
        </div>
        @endauth
    </div>
</nav>

{{-- ── Flash Messages ── --}}
@if(session('success'))
<div class="max-w-screen-xl mx-auto px-4 mt-4">
    <div class="bg-green-100 border border-green-300 text-green-800 rounded-lg px-4 py-3 flex items-center gap-2">
        <svg class="w-5 h-5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
        {{ session('success') }}
    </div>
</div>
@endif

@if(session('error'))
<div class="max-w-screen-xl mx-auto px-4 mt-4">
    <div class="bg-red-100 border border-red-300 text-red-800 rounded-lg px-4 py-3">
        {{ session('error') }}
    </div>
</div>
@endif

{{-- ── Page Content ── --}}
<main class="max-w-screen-xl mx-auto px-4 py-6">
    @yield('content')
</main>

@stack('scripts')
</body>
</html>
