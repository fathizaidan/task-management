<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTaskRequest;
use App\Models\Task;
use App\Models\TaskList;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function create(TaskList $taskList)
    {
        $this->authorize('update', $taskList->board);
        return view('tasks.create', compact('taskList'));
    }

    public function store(StoreTaskRequest $request, TaskList $taskList)
    {
        $this->authorize('update', $taskList->board);

        $position = $taskList->tasks()->max('position') + 1;

        $taskList->tasks()->create(array_merge(
            $request->validated(),
            ['position' => $position]
        ));

        return redirect()
            ->route('boards.show', $taskList->board_id)
            ->with('success', 'Task created!');
    }

    public function show(Task $task)
    {
        $this->authorize('view', $task);
        return view('tasks.show', compact('task'));
    }

    public function edit(Task $task)
    {
        $this->authorize('update', $task);
        $lists = $task->taskList->board->taskLists()->pluck('title', 'id');
        return view('tasks.edit', compact('task', 'lists'));
    }

    public function update(StoreTaskRequest $request, Task $task)
    {
        $this->authorize('update', $task);
        $task->update($request->validated());

        return redirect()
            ->route('boards.show', $task->taskList->board_id)
            ->with('success', 'Task updated!');
    }

    public function destroy(Task $task)
    {
        $this->authorize('delete', $task);
        $boardId = $task->taskList->board_id;
        $task->delete();

        return redirect()
            ->route('boards.show', $boardId)
            ->with('success', 'Task deleted.');
    }

    /**
     * AJAX: move a task to a (possibly different) list and update positions.
     *
     * Body:
     * {
     *   "task_id":     5,
     *   "list_id":     3,
     *   "order":       [5, 2, 7]   // IDs of tasks in the target list in new order
     * }
     */
    public function move(Request $request)
    {
        $data = $request->validate([
            'task_id' => 'required|integer|exists:tasks,id',
            'list_id' => 'required|integer|exists:task_lists,id',
            'order'   => 'required|array',
            'order.*' => 'integer',
        ]);

        $task = Task::findOrFail($data['task_id']);
        $this->authorize('update', $task);

        // Verify target list belongs to same board
        $targetList = TaskList::findOrFail($data['list_id']);
        abort_unless(
            $targetList->board_id === $task->taskList->board_id,
            403,
            'Target list is on a different board.'
        );

        // Move task to the new list
        $task->update(['task_list_id' => $data['list_id']]);

        // Re-index positions for the target list
        foreach ($data['order'] as $position => $id) {
            Task::where('id', $id)->update(['position' => $position]);
        }

        return response()->json(['status' => 'ok']);
    }
}
