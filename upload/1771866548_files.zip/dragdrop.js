/**
 * TaskFlow — Drag & Drop
 * Uses SortableJS (loaded via CDN in layout).
 *
 * Features:
 *  - Drag tasks between lists  → AJAX POST /tasks/move
 *  - Drag to reorder lists     → AJAX POST /boards/{id}/lists/reorder
 */

(function () {
    'use strict';

    const board = document.getElementById('board-container');
    if (!board) return;

    const MOVE_URL    = board.dataset.moveUrl;
    const REORDER_URL = board.dataset.reorderUrl;
    const CSRF        = document.querySelector('meta[name="csrf-token"]').content;

    // ── Helper: POST JSON via fetch ──────────────────────────────────────────
    function postJSON(url, data) {
        return fetch(url, {
            method:  'POST',
            headers: {
                'Content-Type':     'application/json',
                'Accept':           'application/json',
                'X-CSRF-TOKEN':     CSRF,
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: JSON.stringify(data),
        }).then(res => {
            if (!res.ok) {
                console.error('Server error:', res.status);
            }
            return res.json();
        }).catch(err => console.error('Fetch error:', err));
    }

    // ── Sort LISTS horizontally ──────────────────────────────────────────────
    new Sortable(board, {
        animation:     200,
        handle:        '.task-list-column',
        draggable:     '.task-list-column',
        ghostClass:    'sortable-ghost',
        chosenClass:   'sortable-chosen',
        filter:        '.task-cards, input, button, a, form, select, textarea',
        preventOnFilter: false,

        onEnd(evt) {
            const order = [...board.querySelectorAll('.task-list-column')]
                .map(col => col.dataset.listId);
            postJSON(REORDER_URL, { order });
        },
    });

    // ── Sort TASKS within & between lists ────────────────────────────────────
    document.querySelectorAll('.task-cards').forEach(container => {
        new Sortable(container, {
            group:       'tasks',       // shared group = cross-list drag allowed
            animation:   200,
            ghostClass:  'sortable-ghost',
            chosenClass: 'sortable-chosen',
            dataIdAttr:  'data-task-id',

            onEnd(evt) {
                const taskId   = evt.item.dataset.taskId;
                const listId   = evt.to.dataset.listId;

                // Collect new order of IDs in the *destination* list
                const order = [...evt.to.querySelectorAll('.task-card')]
                    .map(card => card.dataset.taskId);

                postJSON(MOVE_URL, { task_id: taskId, list_id: listId, order })
                    .then(data => {
                        if (data && data.status !== 'ok') {
                            console.warn('Move failed, reverting...');
                            // Revert: move item back to origin list
                            evt.from.insertBefore(evt.item, evt.from.children[evt.oldIndex] || null);
                        }
                    });
            },
        });
    });

})();
