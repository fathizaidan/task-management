<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $boards = $request->user()
            ->boards()
            ->withCount('tasks')
            ->with([
                'tasks' => fn ($q) => $q->select('id', 'task_list_id', 'status'),
                'taskLists:id,board_id',
            ])
            ->latest()
            ->get()
            ->map(function ($board) {
                $board->todo_count        = $board->tasks->where('status', 'todo')->count();
                $board->in_progress_count = $board->tasks->where('status', 'in_progress')->count();
                $board->done_count        = $board->tasks->where('status', 'done')->count();
                $board->list_count        = $board->taskLists->count();
                return $board;
            });

        return view('dashboard.index', compact('boards'));
    }
}
