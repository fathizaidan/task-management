<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    use HasFactory;

    protected $fillable = [
        'task_list_id',
        'title',
        'description',
        'due_date',
        'status',
        'priority',
        'position',
    ];

    protected $casts = [
        'due_date' => 'date',
    ];

    // ── Relationships ─────────────────────────────────────────────────────────

    public function taskList(): BelongsTo
    {
        return $this->belongsTo(TaskList::class);
    }

    public function board(): Board
    {
        return $this->taskList->board;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isOverdue(): bool
    {
        return $this->due_date && $this->due_date->isPast() && $this->status !== 'done';
    }

    public function priorityColor(): string
    {
        return match ($this->priority) {
            'high'   => 'red',
            'medium' => 'yellow',
            'low'    => 'green',
            default  => 'gray',
        };
    }

    public function statusLabel(): string
    {
        return match ($this->status) {
            'todo'        => 'To Do',
            'in_progress' => 'In Progress',
            'done'        => 'Done',
            default       => ucfirst($this->status),
        };
    }
}
