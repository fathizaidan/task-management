@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold text-gray-800">My Boards</h1>
    <a href="{{ route('boards.create') }}"
       class="inline-flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        New Board
    </a>
</div>

@if($boards->isEmpty())
    <div class="text-center py-24 bg-white rounded-2xl shadow-sm border border-dashed border-gray-300">
        <svg class="mx-auto w-14 h-14 text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                  d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7"/>
        </svg>
        <p class="text-gray-500 text-lg mb-4">You have no boards yet.</p>
        <a href="{{ route('boards.create') }}"
           class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-semibold transition">
            Create your first board
        </a>
    </div>
@else
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        @foreach($boards as $board)
        <a href="{{ route('boards.show', $board) }}"
           class="group bg-white rounded-2xl shadow hover:shadow-md transition-shadow overflow-hidden flex flex-col">
            {{-- Color bar --}}
            <div class="h-2 w-full" style="background-color: {{ $board->color }}"></div>

            <div class="p-5 flex flex-col flex-1">
                <h2 class="font-bold text-gray-900 text-lg leading-tight group-hover:text-indigo-600 transition">
                    {{ $board->title }}
                </h2>
                @if($board->description)
                    <p class="text-sm text-gray-500 mt-1 line-clamp-2">{{ $board->description }}</p>
                @endif

                {{-- Stats --}}
                <div class="mt-auto pt-4 grid grid-cols-3 gap-2 text-xs text-center">
                    <div class="bg-gray-50 rounded-lg py-2">
                        <div class="font-bold text-gray-700 text-base">{{ $board->todo_count }}</div>
                        <div class="text-gray-400">To Do</div>
                    </div>
                    <div class="bg-blue-50 rounded-lg py-2">
                        <div class="font-bold text-blue-700 text-base">{{ $board->in_progress_count }}</div>
                        <div class="text-blue-400">Doing</div>
                    </div>
                    <div class="bg-green-50 rounded-lg py-2">
                        <div class="font-bold text-green-700 text-base">{{ $board->done_count }}</div>
                        <div class="text-green-400">Done</div>
                    </div>
                </div>

                <div class="mt-3 text-xs text-gray-400 flex justify-between">
                    <span>{{ $board->list_count }} lists</span>
                    <span>{{ $board->tasks_count }} tasks</span>
                </div>
            </div>
        </a>
        @endforeach

        {{-- Add board card --}}
        <a href="{{ route('boards.create') }}"
           class="flex flex-col items-center justify-center bg-gray-50 border-2 border-dashed border-gray-300 hover:border-indigo-400 hover:bg-indigo-50 rounded-2xl p-8 transition group min-h-[180px]">
            <svg class="w-10 h-10 text-gray-400 group-hover:text-indigo-500 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            <span class="mt-2 text-sm text-gray-500 group-hover:text-indigo-600 font-medium">New Board</span>
        </a>
    </div>
@endif
@endsection
