<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTaskRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'title'       => 'required|string|max:200',
            'description' => 'nullable|string|max:2000',
            'due_date'    => 'nullable|date',
            'status'      => ['nullable', Rule::in(['todo', 'in_progress', 'done'])],
            'priority'    => ['nullable', Rule::in(['low', 'medium', 'high'])],
            'task_list_id'=> 'nullable|exists:task_lists,id',
        ];
    }
}
